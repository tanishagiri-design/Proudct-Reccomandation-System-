import pandas as pd
import numpy as np
from scipy.sparse import csr_matrix
from sklearn.neighbors import NearestNeighbors

def load_ratings(csv_path: str) -> pd.DataFrame:
    df = pd.read_csv(csv_path)
    def _clean(s: str) -> str:
        return (s.strip().lower().replace(" ", "").replace("_", "").replace("-", ""))
    cleaned = {c: _clean(c) for c in df.columns}
    df = df.rename(columns=cleaned)
    user_keys   = {"userid", "user", "uid", "customerid", "customer"}
    item_keys   = {"productid", "itemid", "pid", "product", "item"}
    rating_keys = {"rating", "ratings", "score", "stars"}
    def _find(keys):
        for c in df.columns:
            if c in keys: return c
        return None
    user_col   = _find(user_keys)
    item_col   = _find(item_keys)
    rating_col = _find(rating_keys)
    missing = []
    if user_col   is None: missing.append("userId")
    if item_col   is None: missing.append("productId")
    if rating_col is None: missing.append("rating")
    if missing:
        raise ValueError(f"Missing required columns {missing}. Detected: {list(df.columns)}")
    out = df[[user_col, item_col, rating_col]].copy()
    out.columns = ["userId", "productId", "rating"]
    out["userId"]    = out["userId"].astype(str)
    out["productId"] = out["productId"].astype(str)
    out["rating"]    = out["rating"].astype(float)
    return out

class ItemItemRecommender:
    def __init__(self, metric: str = "cosine"):
        self.metric = metric
        self.knn = None
        self.mat = None
        self.u_index = None
        self.i_index = None
        self.idx_item = None

    def fit(self, df: pd.DataFrame):
        users = df["userId"].astype(str).unique().tolist()
        items = df["productId"].astype(str).unique().tolist()
        self.u_index = {u: i for i, u in enumerate(users)}
        self.i_index = {p: i for i, p in enumerate(items)}
        self.idx_item = {i: p for p, i in self.i_index.items()}
        rows = df["userId"].map(self.u_index)
        cols = df["productId"].map(self.i_index)
        vals = df["rating"].astype(float)
        self.mat = csr_matrix((vals, (rows, cols)), shape=(len(users), len(items)), dtype=float)
        self.knn = NearestNeighbors(metric=self.metric).fit(self.mat.T)
        return self

    def recommend(self, user_id: str, n: int = 10, k: int = 25):
        if self.knn is None or self.mat is None:
            raise RuntimeError("Model not fitted. Call .fit(df) first.")
        user_id = str(user_id)
        if user_id not in self.u_index:
            pop = np.array(self.mat.astype(bool).sum(axis=0)).ravel()
            top = pop.argsort()[::-1][:n]
            return [self.idx_item[i] for i in top]
        u = self.u_index[user_id]
        user_vec = self.mat[u]
        seen = set(user_vec.indices)
        scores = {}
        for item_idx, rating in zip(user_vec.indices, user_vec.data):
            dists, neigh = self.knn.kneighbors(self.mat.T[item_idx], n_neighbors=k + 1)
            for dist, nb in zip(dists[0], neigh[0]):
                if nb == item_idx or nb in seen: continue
                sim = 1.0 - float(dist)
                if sim <= 0: continue
                scores[nb] = scores.get(nb, 0.0) + sim * float(rating)
        if not scores:
            pop = np.array(self.mat.astype(bool).sum(axis=0)).ravel()
            top = pop.argsort()[::-1][:n]
            return [self.idx_item[i] for i in top]
        ranked = sorted(scores.items(), key=lambda x: x[1], reverse=True)[:n]
        return [self.idx_item[i] for i, _ in ranked]
