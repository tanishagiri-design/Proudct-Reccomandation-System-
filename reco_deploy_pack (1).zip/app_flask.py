from flask import Flask, request, jsonify
from src.recommender import load_ratings, ItemItemRecommender

CSV_PATH = "data/ratings.csv"
df = load_ratings(CSV_PATH)
model = ItemItemRecommender().fit(df)

app = Flask(__name__)

@app.get("/health")
def health():
    return jsonify({"status": "ok", "ratings": int(len(df))})

@app.get("/recommend")
def recommend():
    user_id = request.args.get("user_id")
    n = int(request.args.get("n", "10"))
    k = int(request.args.get("k", "25"))
    if not user_id:
        return jsonify({"error": "Missing user_id"}), 400
    products = model.recommend(user_id, n=n, k=k)
    return jsonify({"user_id": user_id, "recommendations": products})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000)
