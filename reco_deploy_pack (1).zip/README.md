# Product Recommendation — Deployment Pack

Includes Streamlit UI, Flask API, smart recommender, Dockerfiles, Procfile, render.yaml, requirements.
Place your data at data/ratings.csv (already copied from rating_short.csv if available).

## Local (Streamlit)
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
streamlit run app_streamlit.py

## Local (Flask)
gunicorn -w 2 -b 0.0.0.0:8000 app_flask:app
