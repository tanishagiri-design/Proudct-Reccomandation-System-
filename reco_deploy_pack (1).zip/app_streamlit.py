import streamlit as st
import pandas as pd
from src.recommender import load_ratings, ItemItemRecommender

st.set_page_config(page_title="Product Recommender", page_icon="🛒", layout="wide")
st.title("🛒 Customer → Product Recommendations")

CSV_PATH = "data/ratings.csv"
df = load_ratings(CSV_PATH)
st.caption(f"Loaded {len(df)} ratings from {CSV_PATH}")
st.dataframe(df.head())

reco = ItemItemRecommender().fit(df)

users = sorted(df["userId"].astype(str).unique().tolist())
user_id = st.selectbox("Select userId", users)
n = st.slider("How many recommendations?", 1, 20, 10)
k = st.slider("Neighbor items (k)", 5, 100, 25, step=5)

if st.button("Recommend"):
    products = reco.recommend(user_id=user_id, n=n, k=k)
    out = pd.DataFrame({"productId": products})
    st.subheader("Recommendations")
    st.dataframe(out)
