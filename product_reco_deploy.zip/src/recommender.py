import os
from dataclasses import dataclass
from typing import List, Tuple, Optional, Dict
import numpy as np
import pandas as pd
from scipy.sparse import csr_matrix
from sklearn.neighbors import NearestNeighbors

@dataclass
class FitArtifacts:
    user_index: Dict[str, int]
    item_index: Dict[str, int]
    index_item: Dict[int, str]
    ratings_csr: csr_matrix

class ItemItemRecommender:
    """
    Simple item-item collaborative filtering using cosine distance KNN over a sparse user-item matrix.
    """
    def __init__(self, k: int = 25, min_user_ratings: int = 1, min_item_ratings: int = 1):
        self.k = k
        self.min_user_ratings = min_user_ratings
        self.min_item_ratings = min_item_ratings
        self.knn = None
        self.artifacts: Optional[FitArtifacts] = None

    def _prep(self, df: pd.DataFrame) -> Tuple[csr_matrix, Dict[str, int], Dict[str, int], Dict[int, str]]:
        # Basic cleaning
        df = df.copy()
        # Try to detect standard columns
        def _find(col_name):
            for c in df.columns:
                if c.lower() == col_name:
                    return c
            raise KeyError(f"Missing required column: {col_name}")
        user_col = _find("userid")
        item_col = _find("productid")
        rating_col = _find("rating")

        # Filter by minimums
        if self.min_user_ratings > 1:
            user_counts = df[user_col].value_counts()
            df = df[df[user_col].isin(user_counts[user_counts >= self.min_user_ratings].index)]
        if self.min_item_ratings > 1:
            item_counts = df[item_col].value_counts()
            df = df[df[item_col].isin(item_counts[item_counts >= self.min_item_ratings].index)]

        users = df[user_col].astype(str).unique().tolist()
        items = df[item_col].astype(str).unique().tolist()
        user_index = {u: i for i, u in enumerate(users)}
        item_index = {p: i for i, p in enumerate(items)}
        index_item = {i: p for p, i in item_index.items()}

        rows = df[user_col].astype(str).map(user_index)
        cols = df[item_col].astype(str).map(item_index)
        vals = df[rating_col].astype(float)
        mat = csr_matrix((vals, (rows, cols)), shape=(len(users), len(items)), dtype=float)
        return mat, user_index, item_index, index_item

    def fit(self, ratings: pd.DataFrame) -> "ItemItemRecommender":
        mat, user_index, item_index, index_item = self._prep(ratings)
        # Fit KNN on items (transpose to items x users)
        self.knn = NearestNeighbors(metric="cosine", algorithm="auto")
        self.knn.fit(mat.T)  # items x users
        self.artifacts = FitArtifacts(user_index=user_index, item_index=item_index, index_item=index_item, ratings_csr=mat)
        return self

    def recommend(self, user_id: str, n: int = 10, filter_seen: bool = True) -> List[Tuple[str, float]]:
        if self.knn is None or self.artifacts is None:
            raise RuntimeError("Model not fitted.")
        user_id = str(user_id)
        if user_id not in self.artifacts.user_index:
            # cold start: return popular items
            item_pop = np.array(self.artifacts.ratings_csr.astype(bool).sum(axis=0)).ravel()
            top_idx = np.argsort(-item_pop)[:n]
            return [(self.artifacts.index_item[i], float(item_pop[i])) for i in top_idx]

        uidx = self.artifacts.user_index[user_id]
        user_vector = self.artifacts.ratings_csr[uidx]  # 1 x items

        # Items the user has rated
        seen_items = set(user_vector.indices.tolist())

        scores = {}
        for item_idx, rating in zip(user_vector.indices, user_vector.data):
            distances, neighbors = self.knn.kneighbors(self.artifacts.ratings_csr.T[item_idx], n_neighbors=self.k + 1)
            # neighbors[0][0] will be the item itself
            for dist, nei_idx in zip(distances[0], neighbors[0]):
                if nei_idx == item_idx:
                    continue
                if filter_seen and nei_idx in seen_items:
                    continue
                # cosine distance → similarity
                sim = 1.0 - float(dist)
                if sim <= 0:
                    continue
                scores[nei_idx] = scores.get(nei_idx, 0.0) + sim * float(rating)

        if not scores:
            # fallback to popular
            item_pop = np.array(self.artifacts.ratings_csr.astype(bool).sum(axis=0)).ravel()
            top_idx = np.argsort(-item_pop)[:n]
            return [(self.artifacts.index_item[i], float(item_pop[i])) for i in top_idx]

        ranked = sorted(scores.items(), key=lambda kv: kv[1], reverse=True)[:n]
        return [(self.artifacts.index_item[i], float(s)) for i, s in ranked]

def load_default_ratings(csv_path: str) -> pd.DataFrame:
    df = pd.read_csv(csv_path)
    # normalize likely column names
    rename_map = {}
    for c in df.columns:
        lc = c.lower()
        if lc == "userid" and c != "userId":
            rename_map[c] = "userId"
        if lc == "productid" and c != "productId":
            rename_map[c] = "productId"
        if lc == "rating" and c != "rating":
            rename_map[c] = "rating"
    if rename_map:
        df = df.rename(columns=rename_map)
    return df