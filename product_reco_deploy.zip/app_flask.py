import os
import json
import pandas as pd
from flask import Flask, request, jsonify
from src.recommender import ItemItemRecommender, load_default_ratings

RATINGS_CSV = os.environ.get("RATINGS_CSV", "data/ratings.csv")

df = load_default_ratings(RATINGS_CSV)
model = ItemItemRecommender(k=int(os.environ.get("K", "25"))).fit(df)

app = Flask(__name__)

@app.get("/health")
def health():
    return jsonify({"status": "ok", "ratings": int(len(df))})

@app.get("/recommend")
def recommend():
    user_id = request.args.get("user_id")
    n = int(request.args.get("n", "10"))
    if not user_id:
        return jsonify({"error": "Missing user_id"}), 400
    recs = model.recommend(str(user_id), n=n)
    return jsonify({"user_id": user_id, "n": n, "recommendations": [{"productId": pid, "score": score} for pid, score in recs]})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "8000")))