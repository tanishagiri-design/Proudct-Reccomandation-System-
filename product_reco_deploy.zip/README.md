# Product Recommendation System — Deployment

Two deployment modes are provided:

1) **Streamlit app** (UI)  
2) **Flask API** (REST)

The recommender is a simple **item–item collaborative filtering** (cosine KNN) built from `data/ratings.csv`.

## Local Setup

```bash
python -m venv .venv && source .venv/bin/activate  # On Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

### Run Streamlit (UI)
```bash
export RATINGS_CSV=data/ratings.csv  # optional if you use the bundled file
streamlit run app_streamlit.py
```

### Run Flask (API)
```bash
export RATINGS_CSV=data/ratings.csv
export K=25
gunicorn -w 2 -b 0.0.0.0:8000 app_flask:app
# Or for quick dev:
python app_flask.py
```

Try:
- `GET /health`
- `GET /recommend?user_id=<USER>&n=10`

## Docker

### Streamlit
```bash
docker build -f Dockerfile.streamlit -t reco-streamlit .
docker run -p 8501:8501 -e RATINGS_CSV=data/ratings.csv reco-streamlit
```

### Flask
```bash
docker build -f Dockerfile.flask -t reco-flask .
docker run -p 8000:8000 -e RATINGS_CSV=data/ratings.csv reco-flask
```

## Deploy to Render/Heroku (streamlit)

- Use `Procfile` and set `Build Command: pip install -r requirements.txt`
- Set `Start Command: streamlit run app_streamlit.py --server.port=$PORT --server.address=0.0.0.0`
- Add env var `RATINGS_CSV` if you keep data elsewhere.

## Project Layout
```
.
├── app_flask.py
├── app_streamlit.py
├── data/
│   └── ratings.csv
├── models/
├── src/
│   └── recommender.py
├── Dockerfile.flask
├── Dockerfile.streamlit
├── Procfile
├── README.md
└── requirements.txt
```