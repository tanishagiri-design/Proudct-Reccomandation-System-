import os
import pandas as pd
import streamlit as st
from src.recommender import ItemItemRecommender, load_default_ratings

st.set_page_config(page_title="Product Recommender", page_icon="🛒", layout="wide")

st.title("🛒 Product Recommendation System")
st.write("Item–item collaborative filtering demo (Streamlit). Upload your ratings CSV or use the bundled sample.")

with st.sidebar:
    st.header("Data")
    uploaded = st.file_uploader("Upload ratings CSV (columns: userId, productId, rating)", type=["csv"])
    default_path = os.environ.get("RATINGS_CSV", "data/ratings.csv")
    k = st.slider("Neighbor items (k)", 5, 100, 25, step=5)
    n = st.slider("Recommendations (n)", 1, 30, 10, step=1)

if uploaded is not None:
    df = pd.read_csv(uploaded)
else:
    df = load_default_ratings(default_path)

st.write(f"Loaded **{len(df)}** ratings.")
st.dataframe(df.head())

# Fit model
reco = ItemItemRecommender(k=k).fit(df)

# User input
users = sorted({str(u) for u in df['userId'].astype(str).unique().tolist()})
uid = st.selectbox("Pick a userId", options=users)

if st.button("Recommend"):
    recs = reco.recommend(uid, n=n)
    out_df = pd.DataFrame(recs, columns=["productId", "score"])
    st.subheader("Top Recommendations")
    st.dataframe(out_df)